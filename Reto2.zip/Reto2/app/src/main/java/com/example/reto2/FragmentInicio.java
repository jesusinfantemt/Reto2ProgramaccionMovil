package com.example.reto2;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class FragmentInicio extends Fragment {

    /**
     * Button
     */
    Button boton1;

    TextView texto1;

    View v;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       v = inflater.inflate(R.layout.fragment_inicio, container, false);
        boton1 = (Button) v.findViewById(R.id.boton3);
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                texto1.setText("");
                Toast.makeText(getContext(),"Función en próximas versiones", Toast.LENGTH_SHORT).show();
            }
        });

        texto1 = (TextView) v.findViewById(R.id.texto1);
        return v;
    }



}