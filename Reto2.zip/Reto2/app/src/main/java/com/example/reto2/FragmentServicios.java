package com.example.reto2;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;


public class FragmentServicios extends Fragment {
    Drawable drawable1, drawable2, drawable3;
    ImageView imageView2, imageView3, imageView4;
    Button boton3, boton4, boton5;
    Resources res1,res2,res3;
    View v;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_servicios, container, false);

        res1 = getResources();
        drawable1 = res1.getDrawable(R.drawable.domicilio, v.getContext().getTheme());
        imageView2 = (ImageView) v.findViewById(R.id.imageView2);
        imageView2.setImageDrawable(drawable1);

        res2 = getResources();
        drawable2 = res2.getDrawable(R.drawable.estampado, v.getContext().getTheme());
        imageView3 = (ImageView) v.findViewById(R.id.imageView3);
        imageView3.setImageDrawable(drawable2);

        res3 = getResources();
        drawable3 = res3.getDrawable(R.drawable.confeccion, v.getContext().getTheme());
        imageView4 = (ImageView) v.findViewById(R.id.imageView4);
        imageView4.setImageDrawable(drawable3);

        boton3 = (Button) v.findViewById(R.id.boton3);
        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(),"Función en próximas versiones", Toast.LENGTH_SHORT).show();
            }
        });

        boton4 = (Button) v.findViewById(R.id.boton4);
        boton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getContext(),"Función en próximas versiones", Toast.LENGTH_SHORT).show();
            }
        });

        boton5 = (Button) v.findViewById(R.id.boton5);
        boton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getContext(),"Función en próximas versiones", Toast.LENGTH_SHORT).show();
            }
        });
        return v;
    }
}